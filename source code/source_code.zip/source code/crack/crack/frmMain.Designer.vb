﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.dataHashes = New System.Windows.Forms.DataGridView()
        Me.colHash = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTxt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.listMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.tabImport = New System.Windows.Forms.ToolStripMenuItem()
        Me.tabPurge = New System.Windows.Forms.ToolStripMenuItem()
        Me.tabSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.comboType = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCtrl = New System.Windows.Forms.Button()
        Me.btnList = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblList = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblProdes = New System.Windows.Forms.Label()
        Me.lblRec = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.wlistSelect = New System.Windows.Forms.OpenFileDialog()
        Me.hashSelect = New System.Windows.Forms.OpenFileDialog()
        Me.saveSummary = New System.Windows.Forms.SaveFileDialog()
        CType(Me.dataHashes, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.listMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'dataHashes
        '
        Me.dataHashes.AllowUserToAddRows = False
        Me.dataHashes.AllowUserToDeleteRows = False
        Me.dataHashes.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Silver
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Silver
        Me.dataHashes.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dataHashes.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dataHashes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.dataHashes.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.dataHashes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("MS PGothic", 10.0!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.IndianRed
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Silver
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dataHashes.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dataHashes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dataHashes.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colHash, Me.colTxt})
        Me.dataHashes.ContextMenuStrip = Me.listMenu
        Me.dataHashes.EnableHeadersVisualStyles = False
        Me.dataHashes.GridColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.dataHashes.Location = New System.Drawing.Point(28, 47)
        Me.dataHashes.MultiSelect = False
        Me.dataHashes.Name = "dataHashes"
        Me.dataHashes.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("MS PGothic", 10.0!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Silver
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Silver
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dataHashes.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dataHashes.RowHeadersVisible = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.Silver
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Silver
        Me.dataHashes.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dataHashes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dataHashes.Size = New System.Drawing.Size(510, 176)
        Me.dataHashes.TabIndex = 0
        Me.dataHashes.TabStop = False
        '
        'colHash
        '
        Me.colHash.HeaderText = "[ Hash ]"
        Me.colHash.Name = "colHash"
        Me.colHash.ReadOnly = True
        Me.colHash.Width = 350
        '
        'colTxt
        '
        Me.colTxt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colTxt.HeaderText = "[ Recovered ]"
        Me.colTxt.MinimumWidth = 100
        Me.colTxt.Name = "colTxt"
        Me.colTxt.ReadOnly = True
        '
        'listMenu
        '
        Me.listMenu.BackColor = System.Drawing.Color.Black
        Me.listMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tabImport, Me.tabPurge, Me.tabSave})
        Me.listMenu.Name = "listMenu"
        Me.listMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.listMenu.Size = New System.Drawing.Size(184, 92)
        '
        'tabImport
        '
        Me.tabImport.BackColor = System.Drawing.Color.Black
        Me.tabImport.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.tabImport.Name = "tabImport"
        Me.tabImport.Size = New System.Drawing.Size(183, 22)
        Me.tabImport.Text = "Import from .TXT"
        '
        'tabPurge
        '
        Me.tabPurge.BackColor = System.Drawing.Color.Black
        Me.tabPurge.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.tabPurge.Name = "tabPurge"
        Me.tabPurge.Size = New System.Drawing.Size(183, 22)
        Me.tabPurge.Text = "Clear queue"
        '
        'tabSave
        '
        Me.tabSave.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.tabSave.Name = "tabSave"
        Me.tabSave.Size = New System.Drawing.Size(183, 22)
        Me.tabSave.Text = "Dump results to .TXT"
        '
        'comboType
        '
        Me.comboType.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.comboType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboType.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.comboType.FormattingEnabled = True
        Me.comboType.Items.AddRange(New Object() {"MD5", "SHA-1", "SHA-256", "SHA-384", "SHA-512", "BASE64"})
        Me.comboType.Location = New System.Drawing.Point(138, 20)
        Me.comboType.Name = "comboType"
        Me.comboType.Size = New System.Drawing.Size(77, 21)
        Me.comboType.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 14)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Hashing algorithm:"
        '
        'btnCtrl
        '
        Me.btnCtrl.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnCtrl.Location = New System.Drawing.Point(28, 272)
        Me.btnCtrl.Name = "btnCtrl"
        Me.btnCtrl.Size = New System.Drawing.Size(187, 33)
        Me.btnCtrl.TabIndex = 6
        Me.btnCtrl.Text = "---> CRACK <---"
        Me.btnCtrl.UseVisualStyleBackColor = False
        '
        'btnList
        '
        Me.btnList.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.btnList.Font = New System.Drawing.Font("MS PGothic", 9.0!)
        Me.btnList.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.btnList.Location = New System.Drawing.Point(138, 229)
        Me.btnList.Name = "btnList"
        Me.btnList.Size = New System.Drawing.Size(77, 21)
        Me.btnList.TabIndex = 8
        Me.btnList.Text = ". . . ."
        Me.btnList.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 232)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 14)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Select word list:"
        '
        'lblList
        '
        Me.lblList.Location = New System.Drawing.Point(218, 232)
        Me.lblList.Name = "lblList"
        Me.lblList.Size = New System.Drawing.Size(320, 14)
        Me.lblList.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.IndianRed
        Me.Label4.Location = New System.Drawing.Point(223, 282)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 14)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Probed:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.IndianRed
        Me.Label5.Location = New System.Drawing.Point(381, 282)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 14)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Recovered:"
        '
        'lblProdes
        '
        Me.lblProdes.Location = New System.Drawing.Point(273, 282)
        Me.lblProdes.Name = "lblProdes"
        Me.lblProdes.Size = New System.Drawing.Size(107, 14)
        Me.lblProdes.TabIndex = 12
        Me.lblProdes.Text = "0"
        '
        'lblRec
        '
        Me.lblRec.Location = New System.Drawing.Point(451, 282)
        Me.lblRec.Name = "lblRec"
        Me.lblRec.Size = New System.Drawing.Size(87, 14)
        Me.lblRec.TabIndex = 13
        Me.lblRec.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(426, 23)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(116, 14)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "github.com/waived"
        '
        'wlistSelect
        '
        Me.wlistSelect.DefaultExt = "txt"
        Me.wlistSelect.Filter = "Text File|*.txt"
        '
        'hashSelect
        '
        Me.hashSelect.DefaultExt = "txt"
        Me.hashSelect.Filter = "Text File|*.txt"
        '
        'saveSummary
        '
        Me.saveSummary.DefaultExt = "txt"
        Me.saveSummary.Filter = "Text File|*.txt"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(567, 325)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.lblRec)
        Me.Controls.Add(Me.lblProdes)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblList)
        Me.Controls.Add(Me.btnList)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnCtrl)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.comboType)
        Me.Controls.Add(Me.dataHashes)
        Me.Font = New System.Drawing.Font("MS PGothic", 10.0!)
        Me.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Commando Cracker  -  Ver 0.1"
        Me.TopMost = True
        CType(Me.dataHashes, System.ComponentModel.ISupportInitialize).EndInit()
        Me.listMenu.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dataHashes As DataGridView
    Friend WithEvents comboType As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnCtrl As Button
    Friend WithEvents btnList As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents lblList As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblProdes As Label
    Friend WithEvents lblRec As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents listMenu As ContextMenuStrip
    Friend WithEvents tabImport As ToolStripMenuItem
    Friend WithEvents tabPurge As ToolStripMenuItem
    Friend WithEvents wlistSelect As OpenFileDialog
    Friend WithEvents hashSelect As OpenFileDialog
    Friend WithEvents colHash As DataGridViewTextBoxColumn
    Friend WithEvents colTxt As DataGridViewTextBoxColumn
    Friend WithEvents tabSave As ToolStripMenuItem
    Friend WithEvents saveSummary As SaveFileDialog
End Class
