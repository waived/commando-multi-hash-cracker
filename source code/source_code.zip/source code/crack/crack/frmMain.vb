﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Public Class frmMain
    Public listPath, hashPath As String
    Public killSwitch As Boolean = True
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        comboType.SelectedIndex = 0
        lblList.Select()
    End Sub
    Private Sub tabPurge_Click(sender As Object, e As EventArgs) Handles tabPurge.Click
        If killSwitch = True Then
            dataHashes.Rows.Clear()
            lblProdes.Text = ""
            lblRec.Text = ""
        End If
    End Sub
    Private Sub tabImport_Click(sender As Object, e As EventArgs) Handles tabImport.Click
        If killSwitch = True Then
            If hashSelect.ShowDialog = DialogResult.OK Then
                dataHashes.Rows.Clear()
                hashPath = hashSelect.FileName
                System.Threading.ThreadPool.QueueUserWorkItem(Sub() importAll())
            End If
        End If
    End Sub
    Private Sub importAll()
        CheckForIllegalCrossThreadCalls = False
        Try
            For Each targLine As String In File.ReadLines(hashPath)
                dataHashes.Rows.Add(New String() {targLine, ""})
            Next
        Catch ex As Exception
            MessageBox.Show("Critical error encountered!")
        End Try
    End Sub
    Private Sub btnCtrl_Click(sender As Object, e As EventArgs) Handles btnCtrl.Click
        If btnCtrl.Text = "---> CRACK <---" Then
            If Not (lblList.Text = "" And dataHashes.Rows.Count > 0) Then
                killSwitch = False
                lblProdes.Text = "0"
                lblRec.Text = "0"
                btnCtrl.Text = "---> CANCEL <---"
                If comboType.Text.ToUpper = "MD5" Then
                    System.Threading.ThreadPool.QueueUserWorkItem(Sub() crackMd5())
                ElseIf comboType.Text.ToUpper = "SHA-1" Then
                    System.Threading.ThreadPool.QueueUserWorkItem(Sub() crackSha1())
                ElseIf comboType.Text.ToUpper = "SHA-256" Then
                    System.Threading.ThreadPool.QueueUserWorkItem(Sub() crackSha256())
                ElseIf comboType.Text.ToUpper = "SHA-384" Then
                    System.Threading.ThreadPool.QueueUserWorkItem(Sub() crackSha384())
                ElseIf comboType.Text.ToUpper = "SHA-512" Then
                    System.Threading.ThreadPool.QueueUserWorkItem(Sub() crackSha512())
                ElseIf comboType.Text.ToUpper = "BASE64" Then
                    System.Threading.ThreadPool.QueueUserWorkItem(Sub() crackBase64())
                End If
            End If
        ElseIf btnCtrl.Text = "---> CANCEL <---" Then
            btnCtrl.Enabled = False
            resetUI()
        End If
    End Sub
    Private Sub btnList_Click(sender As Object, e As EventArgs) Handles btnList.Click
        If killSwitch = True Then
            If wlistSelect.ShowDialog = DialogResult.OK Then
                listPath = wlistSelect.FileName
                lblList.Text = Path.GetFileName(listPath)
            End If
        End If
    End Sub
    Private Sub tabSave_Click(sender As Object, e As EventArgs) Handles tabSave.Click
        If Not killSwitch = False Then
            If saveSummary.ShowDialog = DialogResult.OK Then
                Dim sw As System.IO.StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(saveSummary.FileName, True)
                Dim str As String = String.Empty
                For a As Integer = 0 To dataHashes.RowCount - 1
                    str = String.Empty
                    For b As Integer = 0 To dataHashes.ColumnCount - 1
                        str = str & dataHashes.Rows(a).Cells(b).Value.ToString & ":"
                    Next
                    str = str.Substring(0, str.Length - 1)
                    sw.WriteLine(str)
                Next
                sw.Close()
            End If
        End If
    End Sub
    Private Sub crackMd5()
        CheckForIllegalCrossThreadCalls = False
        Try
            Dim probed, recovered As Integer
            For Each chkHash As String In File.ReadLines(listPath)
                If killSwitch = True Then
                    resetUI()
                    Exit Sub
                End If
                Dim x = New System.Security.Cryptography.MD5CryptoServiceProvider()
                Dim computeHash = System.Text.Encoding.UTF8.GetBytes(chkHash)
                computeHash = x.ComputeHash(computeHash)
                Dim stringBuilder = New System.Text.StringBuilder()
                For Each xByte As Byte In computeHash
                    stringBuilder.Append(xByte.ToString("x2").ToLower())
                Next
                Dim result = stringBuilder.ToString()
                For rowIndex As Integer = 0 To dataHashes.RowCount - 1
                    If killSwitch = True Then
                        resetUI()
                        Exit Sub
                    End If
                    Dim targHash As String = dataHashes.Rows(rowIndex).Cells(0).Value
                    probed += 1
                    lblProdes.Text = probed.ToString
                    If result.ToUpper = targHash.ToUpper Then
                        recovered += 1
                        lblRec.Text = recovered.ToString
                        dataHashes.Rows(rowIndex).Cells(1).Value = chkHash
                    End If
                Next
            Next
        Catch ex As Exception
            'Do nothing
        End Try
        resetUI()
    End Sub
    Private Sub crackSha1()
        CheckForIllegalCrossThreadCalls = False
        Try
            Dim probed, recovered As Integer
            For Each chkHash As String In File.ReadLines(listPath)
                If killSwitch = True Then
                    resetUI()
                    Exit Sub
                End If
                Dim sha1Obj As New Security.Cryptography.SHA1CryptoServiceProvider
                Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(chkHash)
                bytesToHash = sha1Obj.ComputeHash(bytesToHash)
                Dim strResult As String = ""
                For Each b As Byte In bytesToHash
                    strResult += b.ToString("x2")
                Next
                Dim result As String = strResult.ToString()
                For rowIndex As Integer = 0 To dataHashes.RowCount - 1
                    If killSwitch = True Then
                        resetUI()
                        Exit Sub
                    End If
                    Dim targHash As String = dataHashes.Rows(rowIndex).Cells(0).Value
                    probed += 1
                    lblProdes.Text = probed.ToString
                    If result.ToUpper = targHash.ToUpper Then
                        recovered += 1
                        lblRec.Text = recovered.ToString
                        dataHashes.Rows(rowIndex).Cells(1).Value = chkHash
                    End If
                Next
            Next
        Catch ex As Exception
            'Do nothing
        End Try
        resetUI()
    End Sub
    Private Sub crackSha256()
        CheckForIllegalCrossThreadCalls = False
        Try
            Dim probed, recovered As Integer
            For Each chkHash As String In File.ReadLines(listPath)
                If killSwitch = True Then
                    resetUI()
                    Exit Sub
                End If
                Dim sha1Obj As New Security.Cryptography.SHA256CryptoServiceProvider
                Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(chkHash)
                bytesToHash = sha1Obj.ComputeHash(bytesToHash)
                Dim strResult As String = ""
                For Each b As Byte In bytesToHash
                    strResult += b.ToString("x2")
                Next
                Dim result As String = strResult.ToString()
                For rowIndex As Integer = 0 To dataHashes.RowCount - 1
                    If killSwitch = True Then
                        resetUI()
                        Exit Sub
                    End If
                    Dim targHash As String = dataHashes.Rows(rowIndex).Cells(0).Value
                    probed += 1
                    lblProdes.Text = probed.ToString
                    If result.ToUpper = targHash.ToUpper Then
                        recovered += 1
                        lblRec.Text = recovered.ToString
                        dataHashes.Rows(rowIndex).Cells(1).Value = chkHash
                    End If
                Next
            Next
        Catch ex As Exception
            'Do nothing
        End Try
        resetUI()
    End Sub
    Private Sub crackSha384()
        CheckForIllegalCrossThreadCalls = False
        Try
            Dim probed, recovered As Integer
            For Each chkHash As String In File.ReadLines(listPath)
                If killSwitch = True Then
                    resetUI()
                    Exit Sub
                End If
                Dim sha1Obj As New Security.Cryptography.SHA384CryptoServiceProvider
                Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(chkHash)
                bytesToHash = sha1Obj.ComputeHash(bytesToHash)
                Dim strResult As String = ""
                For Each b As Byte In bytesToHash
                    strResult += b.ToString("x2")
                Next
                Dim result As String = strResult.ToString()
                For rowIndex As Integer = 0 To dataHashes.RowCount - 1
                    If killSwitch = True Then
                        resetUI()
                        Exit Sub
                    End If
                    Dim targHash As String = dataHashes.Rows(rowIndex).Cells(0).Value
                    probed += 1
                    lblProdes.Text = probed.ToString
                    If result.ToUpper = targHash.ToUpper Then
                        recovered += 1
                        lblRec.Text = recovered.ToString
                        dataHashes.Rows(rowIndex).Cells(1).Value = chkHash
                    End If
                Next
            Next
        Catch ex As Exception
            'Do nothing
        End Try
        resetUI()
    End Sub
    Private Sub crackSha512()
        CheckForIllegalCrossThreadCalls = False
        Try
            Dim probed, recovered As Integer
            For Each chkHash As String In File.ReadLines(listPath)
                If killSwitch = True Then
                    resetUI()
                    Exit Sub
                End If
                Dim sha1Obj As New Security.Cryptography.SHA512CryptoServiceProvider
                Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(chkHash)
                bytesToHash = sha1Obj.ComputeHash(bytesToHash)
                Dim strResult As String = ""
                For Each b As Byte In bytesToHash
                    strResult += b.ToString("x2")
                Next
                Dim result As String = strResult.ToString()
                For rowIndex As Integer = 0 To dataHashes.RowCount - 1
                    If killSwitch = True Then
                        resetUI()
                        Exit Sub
                    End If
                    Dim targHash As String = dataHashes.Rows(rowIndex).Cells(0).Value
                    probed += 1
                    lblProdes.Text = probed.ToString
                    If result.ToUpper = targHash.ToUpper Then
                        recovered += 1
                        lblRec.Text = recovered.ToString
                        dataHashes.Rows(rowIndex).Cells(1).Value = chkHash
                    End If
                Next
            Next
        Catch ex As Exception
            'Do nothing
        End Try
        resetUI()
    End Sub
    Private Sub crackBase64()
        CheckForIllegalCrossThreadCalls = False
        Try
            Dim probed, recovered As Integer
            For Each chkHash As String In File.ReadLines(listPath)
                If killSwitch = True Then
                    resetUI()
                    Exit Sub
                End If
                Dim byt As Byte() = System.Text.Encoding.UTF8.GetBytes(chkHash)
                Dim result As String = Convert.ToBase64String(byt).ToString
                For rowIndex As Integer = 0 To dataHashes.RowCount - 1
                    If killSwitch = True Then
                        resetUI()
                        Exit Sub
                    End If
                    Dim targHash As String = dataHashes.Rows(rowIndex).Cells(0).Value
                    probed += 1
                    lblProdes.Text = probed.ToString
                    If result.ToUpper = targHash.ToUpper Then
                        recovered += 1
                        lblRec.Text = recovered.ToString
                        dataHashes.Rows(rowIndex).Cells(1).Value = chkHash
                    End If
                Next
            Next
        Catch ex As Exception
            'Do nothing
        End Try
        resetUI()
    End Sub
    Private Function resetUI()
        CheckForIllegalCrossThreadCalls = False
        Try
            comboType.SelectedIndex = 0
            lblList.Text = ""
            listPath = ""
            hashPath = ""
            btnCtrl.Text = "---> CRACK <---"
            listMenu.Enabled = True
            btnCtrl.Enabled = True
            killSwitch = True
        Catch ex As Exception
            'Do nothing
        End Try
    End Function
End Class
